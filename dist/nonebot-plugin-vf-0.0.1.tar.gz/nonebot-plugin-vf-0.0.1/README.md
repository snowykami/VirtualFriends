# Virtual Friend
#### nonebot-plugin-virtualfriend

基于Nonebot 2.0 具体使用方法看github
[Project on Github](https://github.com/snowyfirefly/VirtualFriends)